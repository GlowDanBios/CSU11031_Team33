# CSU11031_Team33
Programming project for CSU11031 course. The goal of the project is to s to construct an application to explore data relating to commercial flights.

Member names:
Danila Romanenko - 22338674
Ryan Duffy - 23373365
Stephen McMahon - 23374129
Ben Kelly-Bowen - 23375851
